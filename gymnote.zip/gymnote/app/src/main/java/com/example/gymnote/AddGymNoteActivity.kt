package com.example.gymnote

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.gymnote.databinding.ActivityAddGymNoteBinding
import com.example.gymnote.databinding.ActivityMainBinding

class AddGymNoteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddGymNoteBinding
    private lateinit var db:GymNotesDatabaseHelper


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityAddGymNoteBinding.inflate(layoutInflater)
        db= GymNotesDatabaseHelper(this)
        setContentView(binding.root)

        binding.saveButton.setOnClickListener{
            val title = binding.titleEditText.text.toString()
            val content = binding.contentEditText.text.toString()
            val note = GymNote(0,title,content)
            db.insertNote(note)
            finish()
            Toast.makeText(this,"Note saved", Toast.LENGTH_SHORT).show()

        }
    }
}