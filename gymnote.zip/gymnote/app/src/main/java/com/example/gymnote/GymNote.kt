package com.example.gymnote

data class GymNote(val id:Int, val title: String, val content: String)
